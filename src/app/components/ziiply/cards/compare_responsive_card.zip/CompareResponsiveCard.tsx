import React from "react";

export type CompareStore = {
  id: string;
  name: string;
  chain?: string;
  total?: string;
  savings?: string;
  distance?: string;
  best?: boolean;
};

export type CompareResponsiveCardProps = {
  stores: CompareStore[];
  onChooseStore?: (storeId: string) => void;
  onBack?: () => void;
  onOpenDetails?: (storeId: string) => void;
};

export function CompareResponsiveCard({
  stores,
  onChooseStore,
  onBack,
  onOpenDetails,
}: CompareResponsiveCardProps) {
  const shown =
    stores.length > 0
      ? stores
      : [
          {
            id: "1",
            name: "S-market Tapiola",
            chain: "S-kauppa",
            total: "42,80 €",
            savings: "8,40 €",
            distance: "1,2 km",
            best: true,
          },
          {
            id: "2",
            name: "K-Citymarket Iso Omena",
            chain: "K-kauppa",
            total: "47,30 €",
            savings: "4,10 €",
            distance: "2,4 km",
          },
          {
            id: "3",
            name: "Lidl Niittykumpu",
            chain: "Lidl",
            total: "44,90 €",
            savings: "6,30 €",
            distance: "1,8 km",
          },
        ];

  return (
    <section className="overflow-hidden rounded-[28px] border border-emerald-500/25 bg-gradient-to-br from-black via-zinc-950 to-black text-white shadow-[0_0_50px_rgba(16,185,129,0.18)] lg:rounded-[40px]">
      <div className="relative">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,0.18),transparent_45%)]" />

        <div className="relative p-4 lg:p-8">
          <div className="grid gap-4 lg:grid-cols-[260px_1fr] lg:items-center">
            <div className="flex items-center gap-3 lg:block">
              <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-3xl bg-emerald-500/10 text-5xl ring-1 ring-emerald-500/20 lg:h-64 lg:w-full lg:text-[150px]">
                ⚖️
              </div>

              <div className="lg:hidden">
                <div className="text-sm font-black italic text-emerald-400">
                  Vertaa
                </div>

                <h2 className="text-4xl font-black uppercase leading-none">
                  Kauppavertailu
                </h2>

                <p className="mt-1 text-xs font-black uppercase tracking-[0.18em] text-emerald-400/70">
                  50-luvun hintataulukko
                </p>
              </div>
            </div>

            <div className="hidden lg:block">
              <div className="text-xl font-black italic text-emerald-400">
                Vertaa
              </div>

              <h2 className="text-7xl font-black uppercase leading-none">
                Kauppavertailu
              </h2>

              <p className="mt-3 text-sm font-black uppercase tracking-[0.22em] text-emerald-400/75">
                Gösta analysoi lähikauppojen hinnat
              </p>

              <blockquote className="mt-6 max-w-xl rounded-3xl bg-white/[0.04] p-5 text-2xl font-semibold text-zinc-200 ring-1 ring-white/10">
                “Halvin kori löytyy vertaamalla, ei arvaamalla.”
              </blockquote>
            </div>
          </div>

          <div className="mt-4 rounded-[30px] border border-white/10 bg-white/[0.04] p-4 backdrop-blur lg:mt-8 lg:p-6">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-lg font-black lg:text-3xl">
                  {shown.length} kauppaa vertailtu
                </div>

                <div className="mt-1 text-sm font-semibold text-zinc-300 lg:text-lg">
                  Valitse paras kokonaisuus ostoskorille
                </div>
              </div>

              <div className="rounded-2xl bg-emerald-500 px-4 py-3 text-center text-black shadow-xl shadow-emerald-500/20">
                <div className="text-xs font-black uppercase tracking-[0.16em]">
                  Halvin
                </div>

                <div className="text-2xl font-black">
                  {shown.find((s) => s.best)?.total || "—"}
                </div>
              </div>
            </div>

            <div className="mt-5 space-y-2 lg:space-y-3">
              {shown.map((store) => (
                <article
                  key={store.id}
                  className={`rounded-3xl border p-3 transition-all active:scale-[0.99] lg:p-5 ${
                    store.best
                      ? "border-emerald-400/30 bg-emerald-500/10 shadow-[0_0_30px_rgba(16,185,129,0.15)]"
                      : "border-white/10 bg-black/35"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-2xl lg:h-16 lg:w-16 lg:text-4xl ${
                        store.best
                          ? "bg-emerald-500 text-black"
                          : "bg-white/10"
                      }`}
                    >
                      🛒
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-black lg:text-xl">
                        {store.name}
                      </div>

                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs font-semibold text-zinc-400 lg:text-sm">
                        {store.chain && <span>{store.chain}</span>}
                        {store.distance && <span>• {store.distance}</span>}
                        {store.savings && (
                          <span className="text-emerald-300">
                            • säästö {store.savings}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-right">
                      <div
                        className={`text-lg font-black lg:text-3xl ${
                          store.best ? "text-emerald-300" : "text-white"
                        }`}
                      >
                        {store.total}
                      </div>

                      {store.best && (
                        <div className="mt-1 text-xs font-black uppercase tracking-[0.14em] text-emerald-300">
                          Paras
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => onChooseStore?.(store.id)}
                      className={`min-h-[50px] rounded-2xl px-4 text-sm font-black lg:text-lg ${
                        store.best
                          ? "bg-emerald-500 text-black"
                          : "bg-white/10 text-white ring-1 ring-white/10"
                      }`}
                    >
                      Valitse
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenDetails?.(store.id)}
                      className="min-h-[50px] rounded-2xl bg-black/40 px-4 text-sm font-black text-zinc-100 ring-1 ring-white/10 lg:text-lg"
                    >
                      Tarkemmat
                    </button>
                  </div>
                </article>
              ))}
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3 lg:mt-6">
              <button
                type="button"
                onClick={onBack}
                className="min-h-[58px] rounded-3xl bg-white/10 px-4 text-sm font-black text-white ring-1 ring-white/10 lg:text-xl"
              >
                ← Takaisin
              </button>

              <button
                type="button"
                onClick={() => {
                  const best = shown.find((s) => s.best);
                  if (best) onChooseStore?.(best.id);
                }}
                className="min-h-[58px] rounded-3xl bg-emerald-500 px-4 text-sm font-black text-black shadow-xl shadow-emerald-500/25 lg:text-xl"
              >
                ✓ Valitse halvin
              </button>
            </div>

            <div className="mt-5 text-center text-sm font-semibold italic text-emerald-300/80 lg:text-base">
              “Vertailu on säästäjän paras ystävä.”
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
